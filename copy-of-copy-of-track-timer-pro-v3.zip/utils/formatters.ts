export const formatTime = (timeInMs: number): string => {
  const totalSeconds = Math.floor(timeInMs / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  const milliseconds = Math.floor((timeInMs % 1000) / 10);

  const paddedMinutes = String(minutes).padStart(2, '0');
  const paddedSeconds = String(seconds).padStart(2, '0');
  const paddedMilliseconds = String(milliseconds).padStart(2, '0');

  return `${paddedMinutes}:${paddedSeconds}.${paddedMilliseconds}`;
};

export const calculatePace = (timeInMs: number, distanceInMeters: number): string => {
  if (distanceInMeters === 0 || timeInMs === 0) {
    return '00:00 /km';
  }

  const timeInSeconds = timeInMs / 1000;
  const paceInSecondsPerKm = (timeInSeconds / distanceInMeters) * 1000;

  const minutes = Math.floor(paceInSecondsPerKm / 60);
  const seconds = Math.floor(paceInSecondsPerKm % 60);

  const paddedMinutes = String(minutes).padStart(2, '0');
  const paddedSeconds = String(seconds).padStart(2, '0');

  return `${paddedMinutes}:${paddedSeconds} /km`;
};

export const parseTime = (timeString: string): number => {
  if (!timeString) return 0;

  const parts = timeString.split(':');
  let minutes = 0;
  let seconds = 0;

  try {
    if (parts.length === 2) {
      minutes = parseFloat(parts[0]);
      seconds = parseFloat(parts[1]);
    } else if (parts.length === 1) {
      seconds = parseFloat(parts[0]);
    } else {
      return 0;
    }
  } catch (e) {
    return 0;
  }

  if (isNaN(minutes) || isNaN(seconds)) return 0;

  return Math.round((minutes * 60 + seconds) * 1000);
};

export const msToInputString = (timeInMs: number): string => {
  if (!timeInMs || timeInMs <= 0) return '';
  const totalSeconds = timeInMs / 1000;
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  // e.g. 5.5 becomes "05.50"
  const paddedSeconds = String(seconds.toFixed(2)).padStart(5, '0'); 

  return `${minutes}:${paddedSeconds}`;
};
