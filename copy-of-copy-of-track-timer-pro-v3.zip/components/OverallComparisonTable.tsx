import React from 'react';
import type { Athlete, Lap } from '../types';
import { formatTime } from '../utils/formatters';

interface OverallComparisonTableProps {
  athletes: Athlete[];
}

interface TheoreticalLap {
    totalDistance: number;
    lapTime: number;
    totalTime: number;
}

const generateTheoreticalLaps = (distance: number, time: number, lapDistance: number): TheoreticalLap[] => {
    if (!distance || distance <= 0 || !time || time <= 0 || !lapDistance || lapDistance <= 0) {
      return [];
    }
    const laps: TheoreticalLap[] = [];
    const targetPacePerMeter = time / distance;
    const numLaps = Math.ceil(distance / lapDistance);
    let lastTotalTime = 0;
    for (let i = 1; i <= numLaps; i++) {
      const cumulativeDistance = Math.min(i * lapDistance, distance);
      const totalTime = cumulativeDistance * targetPacePerMeter;
      const lapTime = totalTime - lastTotalTime;
      laps.push({ totalDistance: cumulativeDistance, lapTime, totalTime });
      lastTotalTime = totalTime;
    }
    return laps;
};

const getActualLapTime = (currentLapIndex: number, laps: Lap[]): number => {
    if (laps.length === 0 || currentLapIndex < 0 || currentLapIndex >= laps.length) return 0;
    if (currentLapIndex === 0) {
      return laps[0].totalTime;
    }
    return laps[currentLapIndex].totalTime - laps[currentLapIndex - 1].totalTime;
};


const OverallComparisonTable: React.FC<OverallComparisonTableProps> = ({ athletes }) => {
  if (athletes.length === 0) {
    return null;
  }
  
  return (
    <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 shadow-lg mt-8">
      <h2 className="text-3xl font-bold mb-6 text-cyan-400">Lap-by-Lap Comparison</h2>
      <div className="space-y-8">
        {athletes.map(athlete => {
          const isSimpleMode = athlete.targetDistance <= 0;
          const theoreticalLaps = generateTheoreticalLaps(athlete.targetDistance, athlete.targetTime, athlete.lapDistance);
          const personalBestLaps = generateTheoreticalLaps(athlete.pbDistance, athlete.pbTime, athlete.lapDistance);
          const maxLaps = Math.max(athlete.laps.length, theoreticalLaps.length, personalBestLaps.length);
          
          if (maxLaps === 0) {
              return null;
          }

          return (
            <div key={athlete.id}>
              <h3 className="text-xl font-bold text-cyan-400/90 mb-3">{athlete.name}</h3>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[400px] text-left">
                  <thead>
                    <tr className="border-b border-gray-600">
                      <th className="p-3 font-semibold text-gray-300">{isSimpleMode ? 'Lap' : 'Distance (m)'}</th>
                      <th className="p-3 font-semibold text-gray-300">Actual Lap</th>
                      <th className="p-3 font-semibold text-gray-300">Target Time</th>
                      <th className="p-3 font-semibold text-gray-300">PB Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Array.from({ length: maxLaps }, (_, i) => {
                      const actualLap = athlete.laps[i];
                      const actualLapTime = actualLap ? getActualLapTime(i, athlete.laps) : 0;
                      const theoreticalLap = theoreticalLaps[i];
                      const personalBestLap = personalBestLaps[i];

                      const identifier = isSimpleMode 
                        ? athlete.laps[i]?.lapNumber
                        : athlete.laps[i]?.totalDistance ?? theoreticalLaps[i]?.totalDistance ?? personalBestLaps[i]?.totalDistance;

                      if (identifier === undefined) return null;

                      return (
                         <tr key={identifier} className="border-b border-gray-700 hover:bg-gray-700/50 transition-colors">
                            <td className="p-3 font-bold">{identifier}</td>
                            <td className="p-3 font-mono">{actualLapTime > 0 ? formatTime(actualLapTime) : '-'}</td>
                            <td className="p-3 font-mono">{theoreticalLap ? formatTime(theoreticalLap.totalTime) : '-'}</td>
                            <td className="p-3 font-mono">{personalBestLap ? formatTime(personalBestLap.totalTime) : '-'}</td>
                         </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  );
};

export default OverallComparisonTable;