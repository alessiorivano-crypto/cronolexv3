import React from 'react';
import type { Athlete } from '../types';
import { formatTime, calculatePace } from '../utils/formatters';

interface AthleteComparisonTableProps {
  athletes: Athlete[];
}

const AthleteComparisonTable: React.FC<AthleteComparisonTableProps> = ({ athletes }) => {
  const getBestLapTime = (athlete: Athlete): number => {
    if (athlete.laps.length === 0) return 0;
    const lapTimes = athlete.laps.map((lap, index, laps) => {
      return index === 0 ? lap.totalTime : lap.totalTime - laps[index - 1].totalTime;
    });
    return Math.min(...lapTimes);
  };

  const getLastLapTime = (athlete: Athlete): number => {
    if (athlete.laps.length === 0) return 0;
    const lastLap = athlete.laps[athlete.laps.length - 1];
    return athlete.laps.length === 1 ? lastLap.totalTime : lastLap.totalTime - athlete.laps[athlete.laps.length - 2].totalTime;
  };

  const sortedAthletes = [...athletes].sort((a, b) => {
    if (a.isRunning && !b.isRunning) return -1;
    if (!a.isRunning && b.isRunning) return 1;
    if (a.laps.length !== b.laps.length) return b.laps.length - a.laps.length;
    return a.time - b.time;
  });

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 shadow-lg mt-8">
      <h2 className="text-3xl font-bold mb-6 text-cyan-400">Performance Comparison</h2>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[600px] text-left">
          <thead>
            <tr className="border-b border-gray-600">
              <th className="p-3 font-semibold text-gray-300">Athlete</th>
              <th className="p-3 font-semibold text-gray-300">Status</th>
              <th className="p-3 font-semibold text-gray-300">Total Time</th>
              <th className="p-3 font-semibold text-gray-300">Total Distance (m)</th>
              <th className="p-3 font-semibold text-gray-300">Pace</th>
              <th className="p-3 font-semibold text-gray-300">Laps</th>
              <th className="p-3 font-semibold text-gray-300">Best Lap</th>
              <th className="p-3 font-semibold text-gray-300">Last Lap</th>
            </tr>
          </thead>
          <tbody>
            {athletes.length === 0 ? (
              <tr>
                <td colSpan={8} className="text-center p-8 text-gray-500">Add an athlete to start tracking.</td>
              </tr>
            ) : (
              sortedAthletes.map(athlete => {
                const isSimpleMode = athlete.targetDistance <= 0;
                const totalDistance = athlete.laps.length > 0 ? athlete.laps[athlete.laps.length - 1].totalDistance : 0;
                return (
                  <tr key={athlete.id} className="border-b border-gray-700 hover:bg-gray-700/50 transition-colors">
                    <td className="p-3 font-bold">{athlete.name}</td>
                    <td className="p-3">
                      <span className={`px-2 py-1 text-xs font-semibold rounded-full ${athlete.isRunning ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                        {athlete.isRunning ? 'Running' : 'Stopped'}
                      </span>
                    </td>
                    <td className="p-3 font-mono">{formatTime(athlete.time)}</td>
                    <td className="p-3">{isSimpleMode ? '-' : totalDistance}</td>
                    <td className="p-3 font-mono">{isSimpleMode || totalDistance === 0 ? '-' : calculatePace(athlete.time, totalDistance)}</td>
                    <td className="p-3">{athlete.laps.length}</td>
                    <td className="p-3 font-mono">{formatTime(getBestLapTime(athlete))}</td>
                    <td className="p-3 font-mono">{formatTime(getLastLapTime(athlete))}</td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AthleteComparisonTable;