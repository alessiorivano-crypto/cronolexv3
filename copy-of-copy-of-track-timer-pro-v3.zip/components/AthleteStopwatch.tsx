import React, { useState, useMemo, useEffect } from 'react';
import type { Athlete, Lap } from '../types';
import { formatTime, calculatePace, parseTime, msToInputString } from '../utils/formatters';
import { PlayIcon } from './icons/PlayIcon';
import { PauseIcon } from './icons/PauseIcon';
import { StopIcon } from './icons/StopIcon';
import { FlagIcon } from './icons/FlagIcon';
import { PencilIcon } from './icons/PencilIcon';

interface AthleteStopwatchProps {
  athlete: Athlete;
  onStartStop: (id: number) => void;
  onLap: (id: number) => void;
  onReset: (id: number) => void;
  onRemove: (id: number) => void;
  editingAthleteId: number | null;
  onEdit: (id: number) => void;
  onUpdate: (id: number, updatedData: { name: string; targetDistance: number; targetTime: number; pbTime: number; lapDistance: number; }) => void;
  onCancel: () => void;
}

const AthleteStopwatch: React.FC<AthleteStopwatchProps> = ({ 
  athlete, onStartStop, onLap, onReset, onRemove,
  editingAthleteId, onEdit, onUpdate, onCancel 
}) => {
  const [view, setView] = useState<'actual' | 'theoretical' | 'personalBest'>('actual');
  const isEditing = editingAthleteId === athlete.id;

  const [editData, setEditData] = useState({
    name: athlete.name,
    targetDistance: String(athlete.targetDistance > 0 ? athlete.targetDistance : ''),
    targetTime: msToInputString(athlete.targetTime),
    pbTime: msToInputString(athlete.pbTime),
    lapDistance: String(athlete.lapDistance > 0 ? athlete.lapDistance : ''),
  });
  
  useEffect(() => {
    if (isEditing) {
        setEditData({
            name: athlete.name,
            targetDistance: String(athlete.targetDistance > 0 ? athlete.targetDistance : ''),
            targetTime: msToInputString(athlete.targetTime),
            pbTime: msToInputString(athlete.pbTime),
            lapDistance: String(athlete.lapDistance > 0 ? athlete.lapDistance : ''),
        });
    }
  }, [isEditing, athlete]);

  const handleEditChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEditData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    onUpdate(athlete.id, {
        name: editData.name.trim() || athlete.name,
        targetDistance: parseInt(editData.targetDistance, 10) || 0,
        targetTime: parseTime(editData.targetTime),
        pbTime: parseTime(editData.pbTime),
        lapDistance: parseInt(editData.lapDistance, 10) || 400,
    });
  };

  const getLapTime = (currentLapIndex: number, laps: Lap[]): number => {
    if (currentLapIndex === 0) {
      return laps[0].totalTime;
    }
    return laps[currentLapIndex].totalTime - laps[currentLapIndex - 1].totalTime;
  };
  
  const isSimpleMode = athlete.targetDistance <= 0;

  const theoreticalLaps = useMemo(() => {
    if (!athlete.targetDistance || athlete.targetDistance <= 0 || !athlete.targetTime || athlete.targetTime <= 0 || !athlete.lapDistance || athlete.lapDistance <= 0) {
      return [];
    }
    const laps = [];
    const targetPacePerMeter = athlete.targetTime / athlete.targetDistance;
    const numLaps = Math.ceil(athlete.targetDistance / athlete.lapDistance);
    let lastTotalTime = 0;
    for (let i = 1; i <= numLaps; i++) {
      const cumulativeDistance = Math.min(i * athlete.lapDistance, athlete.targetDistance);
      const totalTime = cumulativeDistance * targetPacePerMeter;
      const lapTime = totalTime - lastTotalTime;
      laps.push({ totalDistance: cumulativeDistance, lapTime, totalTime });
      lastTotalTime = totalTime;
    }
    return laps;
  }, [athlete.targetDistance, athlete.targetTime, athlete.lapDistance]);

  const personalBestLaps = useMemo(() => {
    if (!athlete.pbDistance || athlete.pbDistance <= 0 || !athlete.pbTime || athlete.pbTime <= 0 || !athlete.lapDistance || athlete.lapDistance <= 0) {
      return [];
    }
    const laps = [];
    const targetPacePerMeter = athlete.pbTime / athlete.pbDistance;
    const numLaps = Math.ceil(athlete.pbDistance / athlete.lapDistance);
    let lastTotalTime = 0;
    for (let i = 1; i <= numLaps; i++) {
      const cumulativeDistance = Math.min(i * athlete.lapDistance, athlete.pbDistance);
      const totalTime = cumulativeDistance * targetPacePerMeter;
      const lapTime = totalTime - lastTotalTime;
      laps.push({ totalDistance: cumulativeDistance, lapTime, totalTime });
      lastTotalTime = totalTime;
    }
    return laps;
  }, [athlete.pbDistance, athlete.pbTime, athlete.lapDistance]);

  return (
    <div className="bg-gray-800 rounded-xl p-6 shadow-lg flex flex-col transition-all duration-300 hover:shadow-cyan-500/20 hover:ring-1 hover:ring-cyan-500">
      {isEditing ? (
        <div className="mb-4">
          <div className="space-y-2">
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Athlete Name</label>
              <input type="text" name="name" value={editData.name} onChange={handleEditChange} className="w-full px-3 py-1.5 bg-gray-700 border border-gray-600 rounded-md focus:ring-1 focus:ring-cyan-500 focus:outline-none transition-all text-sm"/>
            </div>
             <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-gray-400 mb-1">Target/PB Dist (m)</label>
                  <input type="number" name="targetDistance" value={editData.targetDistance} onChange={handleEditChange} className="w-full px-3 py-1.5 bg-gray-700 border border-gray-600 rounded-md focus:ring-1 focus:ring-cyan-500 focus:outline-none transition-all text-sm"/>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-400 mb-1">Lap Dist (m)</label>
                  <input type="number" name="lapDistance" value={editData.lapDistance} onChange={handleEditChange} className="w-full px-3 py-1.5 bg-gray-700 border border-gray-600 rounded-md focus:ring-1 focus:ring-cyan-500 focus:outline-none transition-all text-sm"/>
                </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Target Time</label>
              <input type="text" name="targetTime" placeholder="MM:SS.ss" value={editData.targetTime} onChange={handleEditChange} className="w-full px-3 py-1.5 bg-gray-700 border border-gray-600 rounded-md focus:ring-1 focus:ring-cyan-500 focus:outline-none transition-all text-sm"/>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">PB Time</label>
              <input type="text" name="pbTime" placeholder="MM:SS.ss" value={editData.pbTime} onChange={handleEditChange} className="w-full px-3 py-1.5 bg-gray-700 border border-gray-600 rounded-md focus:ring-1 focus:ring-cyan-500 focus:outline-none transition-all text-sm"/>
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <button onClick={handleSave} className="flex-1 px-4 py-2 bg-green-500 text-white font-semibold rounded-lg hover:bg-green-600 transition-colors text-sm">Save</button>
            <button onClick={onCancel} className="flex-1 px-4 py-2 bg-gray-600 text-white font-semibold rounded-lg hover:bg-gray-700 transition-colors text-sm">Cancel</button>
          </div>
        </div>
      ) : (
        <div className="flex justify-between items-start mb-4">
          <div>
            <div className="flex items-center gap-3">
              <h3 className="text-2xl font-bold text-cyan-400">{athlete.name}</h3>
              <button onClick={() => onEdit(athlete.id)} className="text-gray-400 hover:text-white transition-colors print-hidden" aria-label="Edit athlete">
                <PencilIcon className="w-5 h-5" />
              </button>
            </div>
          </div>
          <div className="text-right flex-shrink-0 ml-4">
            <button onClick={() => onRemove(athlete.id)} className="text-gray-500 hover:text-red-500 transition-colors text-2xl leading-none -mt-2 mb-1 ml-auto block print-hidden">&times;</button>
            <div className="text-base text-gray-300 space-y-2">
              <p>
                <span className="font-bold">Lap:</span> <span className="font-semibold text-white">{athlete.lapDistance}m</span>
              </p>
              {athlete.targetTime > 0 && athlete.targetDistance > 0 && (
                <p>
                  <span className="font-bold">Target:</span> <span className="font-semibold text-white">{athlete.targetDistance}m in {formatTime(athlete.targetTime)}</span>
                  <span className="block font-mono text-cyan-400/80 text-sm">
                    ({calculatePace(athlete.targetTime, athlete.targetDistance)})
                  </span>
                </p>
              )}
              {athlete.pbTime > 0 && athlete.pbDistance > 0 && (
                <p>
                  <span className="font-bold">PB:</span> <span className="font-semibold text-white">{athlete.pbDistance}m in {formatTime(athlete.pbTime)}</span>
                  <span className="block font-mono text-cyan-400/80 text-sm">
                    ({calculatePace(athlete.pbTime, athlete.pbDistance)})
                  </span>
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="text-center my-6">
        <p className="text-7xl font-mono tracking-tighter text-white">{formatTime(athlete.time)}</p>
      </div>

      <div className="grid grid-cols-3 gap-4 my-6 print-hidden">
        <button
          onClick={() => onStartStop(athlete.id)}
          className={`flex flex-col items-center justify-center gap-2 p-2 rounded-xl font-semibold transition-all duration-200 aspect-square ${
            athlete.isRunning ? 'bg-yellow-500 hover:bg-yellow-600 text-gray-900' : 'bg-green-500 hover:bg-green-600 text-white'
          }`}
          aria-label={athlete.isRunning ? 'Pause timer' : 'Start timer'}
        >
          {athlete.isRunning ? <PauseIcon className="w-8 h-8"/> : <PlayIcon className="w-8 h-8"/>}
          <span className="text-xs font-bold uppercase tracking-wider">{athlete.isRunning ? 'Pause' : 'Start'}</span>
        </button>
        <button
          onClick={() => onLap(athlete.id)}
          disabled={!athlete.isRunning}
          className="flex flex-col items-center justify-center gap-2 p-2 rounded-xl bg-cyan-500 text-white font-semibold transition-all duration-200 aspect-square hover:bg-cyan-600 disabled:bg-gray-600 disabled:cursor-not-allowed"
          aria-label="Record lap"
        >
          <FlagIcon className="w-8 h-8"/>
          <span className="text-xs font-bold uppercase tracking-wider">Lap</span>
        </button>
        <button
          onClick={() => onReset(athlete.id)}
          disabled={athlete.isRunning}
          className="flex flex-col items-center justify-center gap-2 p-2 rounded-xl bg-red-500 text-white font-semibold transition-all duration-200 aspect-square hover:bg-red-600 disabled:bg-gray-600 disabled:cursor-not-allowed"
          aria-label="Reset timer"
        >
          <StopIcon className="w-8 h-8"/>
          <span className="text-xs font-bold uppercase tracking-wider">Reset</span>
        </button>
      </div>
      
      <div className="flex border-b border-gray-700 mt-4 print-hidden">
        <button onClick={() => setView('actual')} className={`px-3 py-2 text-sm font-semibold transition-colors ${view === 'actual' ? 'border-b-2 border-cyan-400 text-white' : 'text-gray-400 hover:text-white'}`}>Actual Laps</button>
        <button onClick={() => setView('theoretical')} className={`px-3 py-2 text-sm font-semibold transition-colors ${view === 'theoretical' ? 'border-b-2 border-cyan-400 text-white' : 'text-gray-400 hover:text-white'}`}>Theoretical Pace</button>
        <button onClick={() => setView('personalBest')} className={`px-3 py-2 text-sm font-semibold transition-colors ${view === 'personalBest' ? 'border-b-2 border-cyan-400 text-white' : 'text-gray-400 hover:text-white'}`}>Personal Best</button>
      </div>

      <div className="mt-2 flex-grow h-40 overflow-y-auto pr-2">
        {view === 'actual' && (
          athlete.laps.length > 0 ? (
            <table className="w-full text-sm text-left">
              <thead className="sticky top-0 bg-gray-800"><tr><th className="p-2 text-gray-400 font-semibold">{isSimpleMode ? 'Lap' : 'Distance (m)'}</th><th className="p-2 text-gray-400 font-semibold">Lap Time</th><th className="p-2 text-gray-400 font-semibold">Total Time</th></tr></thead>
              <tbody>
                {athlete.laps.slice().reverse().map((lap, index, arr) => {
                    const reversedIndex = arr.length - 1 - index;
                    const lapTime = getLapTime(reversedIndex, athlete.laps);
                    return(<tr key={lap.lapNumber} className="border-b border-gray-700"><td className="p-2">{isSimpleMode ? lap.lapNumber : lap.totalDistance}</td><td className="p-2 font-mono">{formatTime(lapTime)}</td><td className="p-2 font-mono">{formatTime(lap.totalTime)}</td></tr>)
                })}
              </tbody>
            </table>
          ) : (<div className="flex items-center justify-center h-full text-gray-500">No laps recorded.</div>)
        )}
        {view === 'theoretical' && (
          <table className="w-full text-sm text-left">
            <thead className="sticky top-0 bg-gray-800"><tr><th className="p-2 text-gray-400 font-semibold">Distance (m)</th><th className="p-2 text-gray-400 font-semibold">Lap Time</th><th className="p-2 text-gray-400 font-semibold">Total Time</th></tr></thead>
            <tbody>
              {theoreticalLaps.length > 0 ? (theoreticalLaps.map((lap) => (<tr key={lap.totalDistance} className="border-b border-gray-700"><td className="p-2">{lap.totalDistance}</td><td className="p-2 font-mono">{formatTime(lap.lapTime)}</td><td className="p-2 font-mono">{formatTime(lap.totalTime)}</td></tr>))) : (<tr><td colSpan={3} className="text-center p-8 text-gray-500">Set target to see pace.</td></tr>)}
            </tbody>
          </table>
        )}
        {view === 'personalBest' && (
          <table className="w-full text-sm text-left">
            <thead className="sticky top-0 bg-gray-800"><tr><th className="p-2 text-gray-400 font-semibold">Distance (m)</th><th className="p-2 text-gray-400 font-semibold">Lap Time</th><th className="p-2 text-gray-400 font-semibold">Total Time</th></tr></thead>
            <tbody>
              {personalBestLaps.length > 0 ? (personalBestLaps.map((lap) => (<tr key={lap.totalDistance} className="border-b border-gray-700"><td className="p-2">{lap.totalDistance}</td><td className="p-2 font-mono">{formatTime(lap.lapTime)}</td><td className="p-2 font-mono">{formatTime(lap.totalTime)}</td></tr>))) : (<tr><td colSpan={3} className="text-center p-8 text-gray-500">Personal best not set.</td></tr>)}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default AthleteStopwatch;